import { subtitle, title } from "@/components/primitives";
import DefaultLayout from "@/layouts/default";
import { Quiz } from "@/types";
import { useRouter } from "next/router";
import { Button } from "@nextui-org/button";

export interface QuizPageProps {
  quiz: Quiz;
}

export default function QuizDetail({ quiz }: QuizPageProps) {
  const router = useRouter();

  const startQuiz = () => {
    router.push(`/quiz/${quiz?.id}/question/${quiz?.questions[0].id}`);
  };

  if (!quiz) return <p>Quiz not found</p>;

  return (
    <DefaultLayout>
      <section className="flex flex-col items-center align-middle justify-center gap-4 py-8 md:py-10 h-full">
        <div className="inline-block max-w-xl text-center justify-center">
          <span className={title()}>{quiz.title}</span>
          <br />
          <div className={subtitle({ class: "mt-4" })}>{quiz.description}</div>
        </div>

        <Button onClick={startQuiz} color="success" size="lg">
          Start quiz!
        </Button>
      </section>
    </DefaultLayout>
  );
}

export async function getServerSideProps(context: any) {
  const { quizId } = context.params;
  const quizzezRequest = await fetch(`http://localhost:3000/quizzez.json`);
  const quizzes: Quiz[] = await quizzezRequest.json();

  const quiz = quizzes.find((quiz) => quiz.id === parseInt(quizId));

  if (!quiz) {
    return {
      notFound: true,
    };
  }

  return {
    props: { quiz },
  };
}
